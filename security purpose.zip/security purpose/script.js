"use strict";

/* =========================================
   HASHSECURE - APPLICATION CONFIGURATION
========================================= */

const algorithms = {
    "SHA-1": {
        bits: 160,
        length: 40
    },
    "SHA-256": {
        bits: 256,
        length: 64
    },
    "SHA-384": {
        bits: 384,
        length: 96
    },
    "SHA-512": {
        bits: 512,
        length: 128
    }
};

let generatedHash = "";
let generatedAlgorithm = "";
let generatedInputLength = 0;
let generatedDate = null;

/* =========================================
   DOM ELEMENTS
========================================= */

const inputText = document.getElementById("inputText");

const charCount = document.getElementById("charCount");
const wordCount = document.getElementById("wordCount");
const byteCount = document.getElementById("byteCount");

const generateBtn = document.getElementById("generateBtn");
const loadingOverlay = document.getElementById("loadingOverlay");

const emptyResult = document.getElementById("emptyResult");
const resultContent = document.getElementById("resultContent");
const resultStatus = document.getElementById("resultStatus");

const hashOutput = document.getElementById("hashOutput");

const resultAlgorithm = document.getElementById("resultAlgorithm");
const resultBits = document.getElementById("resultBits");
const resultLength = document.getElementById("resultLength");

const resultChars = document.getElementById("resultChars");
const resultDate = document.getElementById("resultDate");

const toastContainer = document.getElementById("toastContainer");

/* =========================================
   SECURITY CHECK
========================================= */

function checkCryptoSupport() {
    if (!window.crypto || !window.crypto.subtle) {
        showToast(
            "Web Crypto API unavailable. Use HTTPS or localhost.",
            "error"
        );

        generateBtn.disabled = true;
        generateBtn.style.opacity = "0.5";

        return false;
    }

    return true;
}

/* =========================================
   UTF-8 AND HASH UTILITIES
========================================= */

function encodeText(text) {
    return new TextEncoder().encode(text);
}

function bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer))
        .map(byte => byte.toString(16).padStart(2, "0"))
        .join("");
}

async function createHash(text, algorithm) {

    if (!checkCryptoSupport()) {
        throw new Error("Cryptographic API is unavailable.");
    }

    const encodedData = encodeText(text);

    const digest = await crypto.subtle.digest(
        algorithm,
        encodedData
    );

    return bufferToHex(digest);
}

/* =========================================
   INPUT STATISTICS
========================================= */

function updateInputStatistics() {

    const text = inputText.value;

    const characters = text.length;

    const words = text.trim()
        ? text.trim().split(/\s+/u).length
        : 0;

    const bytes = encodeText(text).length;

    charCount.textContent = characters;
    wordCount.textContent = words;
    byteCount.textContent = bytes;
}

inputText.addEventListener("input", updateInputStatistics);

/* =========================================
   CLEAR INPUT
========================================= */

document.getElementById("clearInputBtn")
    .addEventListener("click", () => {

        inputText.value = "";

        updateInputStatistics();

        inputText.focus();

        showToast("Input cleared successfully.", "success");
    });

/* =========================================
   PASTE FROM CLIPBOARD
========================================= */

document.getElementById("pasteBtn")
    .addEventListener("click", async () => {

        try {

            if (!navigator.clipboard || !navigator.clipboard.readText) {
                throw new Error("Clipboard access unavailable.");
            }

            const text = await navigator.clipboard.readText();

            inputText.value = text;

            updateInputStatistics();

            inputText.focus();

            showToast("Text pasted successfully.", "success");

        } catch (error) {

            showToast(
                "Clipboard permission denied or unavailable.",
                "error"
            );

        }
    });

/* =========================================
   SELECTED ALGORITHM
========================================= */

function getSelectedAlgorithm() {

    const selected = document.querySelector(
        'input[name="algorithm"]:checked'
    );

    return selected ? selected.value : "SHA-256";
}

/* =========================================
   GENERATE HASH
========================================= */

generateBtn.addEventListener("click", generateSecureHash);

async function generateSecureHash() {

    const text = inputText.value;

    if (text.length === 0) {

        showToast(
            "Please enter some text before generating a hash.",
            "warning"
        );

        inputText.focus();

        return;
    }

    if (!checkCryptoSupport()) return;

    const algorithm = getSelectedAlgorithm();

    generateBtn.disabled = true;

    loadingOverlay.classList.remove("hidden");

    const buttonContent = generateBtn.innerHTML;

    generateBtn.innerHTML = `
        <i class="fa-solid fa-spinner fa-spin"></i>
        Processing...
    `;

    try {

        // Allow the browser to render the loading interface.
        await new Promise(resolve => setTimeout(resolve, 100));

        const hash = await createHash(text, algorithm);

        generatedHash = hash;
        generatedAlgorithm = algorithm;
        generatedInputLength = text.length;
        generatedDate = new Date();

        displayHashResult();

        showToast(
            `${algorithm} hash generated successfully!`,
            "success"
        );

    } catch (error) {

        console.error("Hash generation error:", error);

        showToast(
            "Hash generation failed. Please try again.",
            "error"
        );

    } finally {

        loadingOverlay.classList.add("hidden");

        generateBtn.disabled = false;

        generateBtn.innerHTML = buttonContent;
    }
}

/* =========================================
   DISPLAY HASH RESULT
========================================= */

function displayHashResult() {

    const info = algorithms[generatedAlgorithm];

    emptyResult.classList.add("hidden");
    resultContent.classList.remove("hidden");

    resultStatus.textContent = "GENERATED";
    resultStatus.classList.add("ready");

    resultAlgorithm.textContent = generatedAlgorithm;

    resultBits.textContent = `${info.bits} Bits`;

    resultLength.textContent = `${info.length} Characters`;

    resultChars.textContent = generatedInputLength;

    resultDate.textContent = generatedDate.toLocaleTimeString();

    hashOutput.textContent = generatedHash;
}

/* =========================================
   COPY HASH
========================================= */

async function copyText(text) {

    if (!text) {
        showToast("Nothing to copy.", "warning");
        return;
    }

    try {

        if (navigator.clipboard && navigator.clipboard.writeText) {

            await navigator.clipboard.writeText(text);

        } else {

            const temporary = document.createElement("textarea");

            temporary.value = text;

            temporary.style.position = "fixed";
            temporary.style.opacity = "0";

            document.body.appendChild(temporary);

            temporary.select();

            const successful = document.execCommand("copy");

            temporary.remove();

            if (!successful) {
                throw new Error("Copy operation failed.");
            }
        }

        showToast("Hash copied successfully!", "success");

    } catch (error) {

        showToast("Unable to copy. Check clipboard permissions.", "error");
    }
}

document.getElementById("copyHashBtn")
    .addEventListener("click", () => {
        copyText(generatedHash);
    });

/* =========================================
   FULL HASH MODAL
========================================= */

const hashModal = document.getElementById("hashModal");

document.getElementById("fullHashBtn")
    .addEventListener("click", () => {

        if (!generatedHash) return;

        document.getElementById("modalHash").textContent =
            generatedHash;

        hashModal.classList.remove("hidden");
    });

document.getElementById("closeModal")
    .addEventListener("click", closeHashModal);

function closeHashModal() {
    hashModal.classList.add("hidden");
}

hashModal.addEventListener("click", event => {

    if (event.target === hashModal) {
        closeHashModal();
    }
});

document.getElementById("modalCopyBtn")
    .addEventListener("click", () => {
        copyText(generatedHash);
    });

document.addEventListener("keydown", event => {

    if (event.key === "Escape") {
        closeHashModal();
    }
});

/* =========================================
   DOWNLOAD HASH
========================================= */

document.getElementById("downloadHashBtn")
    .addEventListener("click", downloadHash);

function downloadHash() {

    if (!generatedHash) {

        showToast("Generate a hash first.", "warning");

        return;
    }

    const report = `
========================================
             HASHSECURE
       CRYPTOGRAPHIC HASH REPORT
========================================

Application: HashSecure
Algorithm: ${generatedAlgorithm}
Digest Size: ${algorithms[generatedAlgorithm].bits} Bits
Hash Length: ${generatedHash.length} Characters

Original Input Character Count: ${generatedInputLength}

Generation Date:
${generatedDate.toLocaleString()}

----------------------------------------
GENERATED HASH
----------------------------------------

${generatedHash}

----------------------------------------
SECURITY INFORMATION
----------------------------------------

HashSecure uses the browser Web Crypto API.

Your original input is processed locally.

Hashing is a one-way operation and is not encryption.

========================================
`;

    const blob = new Blob(
        [report.trim()],
        { type: "text/plain;charset=utf-8" }
    );

    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");

    link.href = url;

    link.download =
        `HashSecure_${generatedAlgorithm}_${Date.now()}.txt`;

    document.body.appendChild(link);

    link.click();

    link.remove();

    URL.revokeObjectURL(url);

    showToast("Hash report downloaded successfully!", "success");
}

/* =========================================
   CLEAR GENERATED RESULT
========================================= */

document.getElementById("clearResultBtn")
    .addEventListener("click", clearHashResult);

function clearHashResult() {

    generatedHash = "";
    generatedAlgorithm = "";
    generatedInputLength = 0;
    generatedDate = null;

    resultContent.classList.add("hidden");

    emptyResult.classList.remove("hidden");

    resultStatus.textContent = "WAITING";

    resultStatus.classList.remove("ready");

    showToast("Generated result cleared.", "success");
}

/* =========================================
   MOVE TO COMPARISON SECTION
========================================= */

document.getElementById("resultCompareBtn")
    .addEventListener("click", () => {

        if (!generatedHash) return;

        document.getElementById("firstHash").value = generatedHash;

        document.getElementById("comparison")
            .scrollIntoView({ behavior: "smooth" });

        showToast("Generated hash added to comparison.", "success");
    });

/* =========================================
   HASH VERIFICATION
========================================= */

const verifyBtn = document.getElementById("verifyBtn");

verifyBtn.addEventListener("click", verifyHash);

async function verifyHash() {

    const originalText =
        document.getElementById("verifyText").value;

    const expectedHash =
        document.getElementById("expectedHash").value.trim();

    const algorithm =
        document.getElementById("verifyAlgorithm").value;

    const result = document.getElementById("verifyResult");

    if (!originalText.length || !expectedHash) {

        showToast(
            "Please enter both original text and expected hash.",
            "warning"
        );

        return;
    }

    if (!/^[0-9a-f]+$/i.test(expectedHash)) {

        showToast(
            "Expected hash must contain hexadecimal characters only.",
            "error"
        );

        return;
    }

    const expectedLength = algorithms[algorithm].length;

    if (expectedHash.length !== expectedLength) {

        showToast(
            `Invalid hash length. ${algorithm} requires ${expectedLength} hexadecimal characters.`,
            "error"
        );

        return;
    }

    verifyBtn.disabled = true;

    verifyBtn.innerHTML =
        '<i class="fa-solid fa-spinner fa-spin"></i> Verifying...';

    try {

        const actualHash = await createHash(
            originalText,
            algorithm
        );

        const matched = constantTimeEqual(
            actualHash,
            expectedHash.toLowerCase()
        );

        if (matched) {

            showToolResult(
                result,
                true,
                "HASH MATCHED",
                "The generated hash matches the expected hash. Data integrity verified."
            );

            showToast("Hash verification successful!", "success");

        } else {

            showToolResult(
                result,
                false,
                "HASH MISMATCHED",
                "The generated hash does not match the expected hash. The data may have changed."
            );

            showToast("Hash verification failed.", "error");
        }

    } catch (error) {

        showToast("Verification failed. Please try again.", "error");

    } finally {

        verifyBtn.disabled = false;

        verifyBtn.innerHTML =
            '<i class="fa-solid fa-shield-halved"></i> Verify Integrity';
    }
}

/* =========================================
   CONSTANT-TIME STRING COMPARISON
========================================= */

function constantTimeEqual(first, second) {

    if (first.length !== second.length) {
        return false;
    }

    let difference = 0;

    for (let i = 0; i < first.length; i++) {

        difference |=
            first.charCodeAt(i) ^ second.charCodeAt(i);
    }

    return difference === 0;
}

/* =========================================
   HASH COMPARISON
========================================= */

const compareBtn = document.getElementById("compareBtn");

compareBtn.addEventListener("click", compareHashes);

function compareHashes() {

    const firstHash =
        document.getElementById("firstHash").value.trim();

    const secondHash =
        document.getElementById("secondHash").value.trim();

    const result = document.getElementById("compareResult");

    if (!firstHash || !secondHash) {

        showToast(
            "Please enter both hash values.",
            "warning"
        );

        return;
    }

    if (
        !/^[0-9a-f]+$/i.test(firstHash) ||
        !/^[0-9a-f]+$/i.test(secondHash)
    ) {

        showToast(
            "Hash values must contain hexadecimal characters only.",
            "error"
        );

        return;
    }

    const matched = constantTimeEqual(
        firstHash.toLowerCase(),
        secondHash.toLowerCase()
    );

    if (matched) {

        showToolResult(
            result,
            true,
            "HASHES MATCH",
            "Both hash values are identical."
        );

        showToast("Both hashes match!", "success");

    } else {

        showToolResult(
            result,
            false,
            "HASHES DO NOT MATCH",
            "The two hash values are different."
        );

        showToast("Hash values do not match.", "error");
    }
}

/* =========================================
   CLEAR COMPARISON
========================================= */

document.getElementById("clearCompareBtn")
    .addEventListener("click", () => {

        document.getElementById("firstHash").value = "";

        document.getElementById("secondHash").value = "";

        document.getElementById("compareResult")
            .classList.add("hidden");

        showToast("Comparison fields cleared.", "success");
    });

/* =========================================
   COMMON RESULT DISPLAY
========================================= */

function showToolResult(element, matched, title, message) {

    element.className = "tool-result";

    element.classList.add(
        matched ? "match" : "mismatch"
    );

    element.innerHTML = `
        <i class="fa-solid ${
            matched ? "fa-circle-check" : "fa-circle-xmark"
        }"></i>

        <div>
            <h3>${title}</h3>
            <p>${message}</p>
        </div>
    `;
}

/* =========================================
   TOAST NOTIFICATIONS
========================================= */

function showToast(message, type = "success") {

    const toast = document.createElement("div");

    toast.className = `toast ${type}`;

    const icon = {
        success: "fa-circle-check",
        error: "fa-circle-xmark",
        warning: "fa-triangle-exclamation"
    };

    const iconElement = document.createElement("i");

    iconElement.className = `fa-solid ${icon[type] || icon.success}`;

    const textElement = document.createElement("span");

    textElement.textContent = message;

    toast.appendChild(iconElement);

    toast.appendChild(textElement);

    toastContainer.appendChild(toast);

    setTimeout(() => {

        toast.classList.add("hide");

        setTimeout(() => toast.remove(), 300);

    }, 3000);
}

/* =========================================
   MOBILE NAVIGATION
========================================= */

const menuToggle = document.getElementById("menuToggle");

const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", () => {

    navLinks.classList.toggle("open");

    const icon = menuToggle.querySelector("i");

    icon.classList.toggle("fa-bars");

    icon.classList.toggle("fa-xmark");
});

document.querySelectorAll(".nav-link").forEach(link => {

    link.addEventListener("click", () => {

        navLinks.classList.remove("open");

        const icon = menuToggle.querySelector("i");

        icon.classList.remove("fa-xmark");

        icon.classList.add("fa-bars");
    });
});

/* =========================================
   ACTIVE NAVIGATION ON SCROLL
========================================= */

const sections = document.querySelectorAll("main section[id]");

const navigationLinks = document.querySelectorAll(".nav-link");

function updateActiveNavigation() {

    let currentSection = "home";

    sections.forEach(section => {

        const sectionTop = section.offsetTop - 160;

        if (window.scrollY >= sectionTop) {
            currentSection = section.id;
        }
    });

    navigationLinks.forEach(link => {

        link.classList.remove("active");

        if (
            link.getAttribute("href") === `#${currentSection}`
        ) {
            link.classList.add("active");
        }
    });
}

window.addEventListener("scroll", updateActiveNavigation);

/* =========================================
   INITIALIZATION
========================================= */

document.addEventListener("DOMContentLoaded", () => {

    updateInputStatistics();

    checkCryptoSupport();

    console.log(
        "%c HashSecure Initialized Successfully ",
        "background:#00D4FF;color:#080F1F;font-weight:bold;padding:8px;"
    );

    console.log(
        "Cryptographic algorithms:",
        Object.keys(algorithms)
    );
});